Diamond.exe by snare
this is a malware
DISCLAIMER: do not run non-safety on your main pc because it will destroy your mbr you should run safety on your real pc
i'm not responsible for any damage made to your computer.

if windows vista is still slow try windows 7